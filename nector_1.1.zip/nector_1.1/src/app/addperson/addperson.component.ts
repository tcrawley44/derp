import { Component,  Injectable } from '@angular/core';
import { PeopleService } from '../people.service';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-add-person',
  templateUrl: './addperson.component.html'

})



@Injectable({providedIn: 'root'})
export class AddPersonComponent {
  name = '';
  gender = '';
  age = '';
  city = '';
  state = '';
  output;
  constructor(public peopleService: PeopleService ) {}

  onAddPost(form: NgForm) {

      this.name = form.value.name;
      /* this.gender: form.value.gender,
      this.age: form.value.age,
      this.city: form.value.city,
      this.state: form.value.state
      */

    this.output = this.name;
    this.peopleService.addPeople(this.name);
  }


}
