import { Component } from '@angular/core';
import { PeopleService } from '../people.service';
import { OnInit} from '@angular/core';


@Component({
  selector: 'app-list-people',
  templateUrl: './listpeople.component.html'

})

export class ListPeopleComponent implements OnInit {

    constructor(public peopleService: PeopleService) {}

    people = [];
    ngOnInit() {
      this.people = this.peopleService.getPeople();
    }
}
