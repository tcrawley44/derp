import { Component } from '@angular/core';

@Component({
  selector: 'app-toolbar',
  templateUrl: './Toolbar.component.html',
  styleUrls: ['./Toolbar.component.css']
})

export class ToolbarComponent {
}
