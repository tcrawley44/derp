import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PostCreateComponent } from './posts/post-create/post-create.component';
import { AddPersonComponent } from './addperson/addperson.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ListPeopleComponent } from './listpeople/listpeople.component';

const routes: Routes = [
    {path: '', component: HomepageComponent},
    {path: 'addPerson', component: AddPersonComponent},
    {path: 'listPeople', component:  ListPeopleComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
