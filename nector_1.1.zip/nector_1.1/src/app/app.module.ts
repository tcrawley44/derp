import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatToolbarModule} from '@angular/material';
import {MatInputModule} from '@angular/material';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PostCreateComponent} from './posts/post-create/post-create.component';
import { AddPersonComponent } from './addperson/addperson.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToolbarComponent } from './Toolbar/toolbar.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ListPeopleComponent } from './listpeople/listpeople.component';

@NgModule({
  declarations: [
    AppComponent,
    PostCreateComponent,
    AddPersonComponent,
    ToolbarComponent,
    HomepageComponent,
    ListPeopleComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatInputModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
