import { Injectable } from '@angular/core';


@Injectable({providedIn: 'root'})
export class PeopleService {
  private people = [];

  getPeople() {
    return this.people;
  }

  addPeople(name: String) {


      this.people.push(name);

  }

}
