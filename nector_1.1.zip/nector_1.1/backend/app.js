const express = require('express');

const app = express();




app.use('/posts' ,(req,res,next) => {
  const posts = [
    {
      id: "djoeofj",
      title: "first server post",
      content: "from the server"
    },

    {
      id: "ddfdjoedffdofj",
      title: "sec server post",
      content: "from the serverrrr"
    }
  ];
  res.status(200).json(posts);
});


module.exports = app;
